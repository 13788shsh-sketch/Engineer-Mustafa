# My Android Phone

مشروع HTML/CSS/JavaScript جاهز للنشر.

## التشغيل
افتح `index.html` في المتصفح.

## النشر
ارفع `index.html` إلى GitHub Pages أو أي استضافة مواقع ثابتة.

## Google Play
أزرار التطبيقات تفتح صفحات Google Play الرسمية في نافذة جديدة.
هذا المشروع لا يثبت APK داخل المتصفح.
